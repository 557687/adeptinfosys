<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Adeptinfosys</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/Adeptlogo.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!--  Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="index.html" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <img src="img/Adeptlogo.png" alt="" srcset="" style="height: 60px;"><h2 class="m-0 text-primary mt-3 ms-2"><br><p style="font-size:10px; color:red;"></p></h2>
        </a>
        <!-- <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">-->
        <!--    <span class="navbar-toggler-icon"></span>-->
        <!--</button> -->
        
     
        
    </nav>
    <!-- Navbar End -->
    
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0" style="background: linear-gradient(80deg, #26a8f3 10%, #8abf57 50%) !important;height:70px;">
        
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <!-- <a href="/" class="nav-item nav-link active">Home</a> -->
                <a href="index.php" class="nav-item nav-link">Home</a>
                <a href="about.php" class="nav-item nav-link">About Us</a>
                
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">TRAINING</a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="team.php" class="dropdown-item">Course Offered</a>
                        <a href="testimonial.php" class="dropdown-item">Skill Development</a>
                        <a href="#" class="dropdown-item">Youth Empowerment</a>
                        <a href="testimonial.php" class="dropdown-item">Women Empowerment</a>
                        <a href="404.php" class="dropdown-item">Special Programs</a>
                    </div>
                </div>
                <!--<a href="pay_school_fee.php" class="nav-item nav-link"></a>-->
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Admission</a>
                    <div class="dropdown-menu fade-down m-0">
                        <!--<a href="#" class="dropdown-item">Admission Procedure</a>-->
                        <a href="#" class="dropdown-item">Admission Form</a>
                    </div>
                </div>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">ACTIVITIES</a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="team.php" class="dropdown-item">Yojna</a>
                        <!--<a href="testimonial.php" class="dropdown-item">Games & Sports</a>-->
                        <a href="404.php" class="dropdown-item">Visit</a>
                    </div>
                </div>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">ACHIEVEMENTS</a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="team.php" class="dropdown-item">Achievements</a>
                        
                    </div>
                </div>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">FACILITIES</a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="team.php" class="dropdown-item">Library</a>
                        <a href="testimonial.php" class="dropdown-item">Computer Lab</a>
                    </div>
                </div>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">FACULTY</a>
                    <div class="dropdown-menu fade-down m-0">
                        <a href="team.php" class="dropdown-item">Teaching Staff</a>
                        <!--<a href="testimonial.php" class="dropdown-item">Class Teacher</a>-->
                    </div>
                </div>
                <a href="gallery.php" class="nav-item nav-link">GALLERY</a>  
                <a href="career.php" class="nav-item nav-link">Careers</a>
                <a href="login.php" class="nav-item nav-link">Login</a>
            </div>
            
        </div>
    </nav>
    <!-- Navbar End -->
    