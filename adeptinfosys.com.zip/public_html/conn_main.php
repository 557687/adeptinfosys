
<!--database connection-->
<?php
$servername = "localhost";   // Server name
$username = "u182879714_adept";      // Database username
$password = "Adeptinfo@123";      // Database password
$dbname = "u182879714_adept";   // Database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
// echo "Connected successfully";
?>

