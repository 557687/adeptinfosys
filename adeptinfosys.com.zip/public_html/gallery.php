<!--Header -->
 <?php include 'header.php'; ?>
 
 <!-- First Gallery start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Gallery</h6>
                <h1 class="mb-5">Our Gallery</h1>
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/G1.jpeg" alt=""style="height:200px;">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Take a Respect</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/G2.jpeg" alt="">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Speech</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/G3.jpeg" alt="">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Class Room</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/G4.jpeg" alt="">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Inauguration</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--First gallery end-->
    
    <!--Second gallery start-->
     <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <!--<h6 class="section-title bg-white text-center text-primary px-3">Gallery</h6>-->
                <!--<h1 class="mb-5">Our Gallery</h1>-->
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/G6.jpeg" alt=""style="height:200px;">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Lighting of Lamp</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/G7.jpeg" alt="">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Inauguration</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/G8.jpeg" alt="">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Conference Room</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/G9.jpeg" alt="">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Working Area</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Second gallery-->
    
    <!--third  gallery start-->
     <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <!--<h6 class="section-title bg-white text-center text-primary px-3">Gallery</h6>-->
                <!--<h1 class="mb-5">Our Gallery</h1>-->
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/G10.jpeg" alt=""style="height:200px;">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Visit</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden"style="height:200px;">
                            <img class="img-fluid" src="img/G11.jpeg" alt="">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Training</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden"style="height:200px;">
                            <img class="img-fluid" src="img/G12.jpeg" alt=""style="width:260px;">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Working Area</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/G5.jpeg" alt="">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Gift a Bouquet</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--third Gallery end -->
    
    <!-Fourth gallery start--->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <!--<h6 class="section-title bg-white text-center text-primary px-3">Gallery</h6>-->
                <!--<h1 class="mb-5">Our Gallery</h1>-->
            </div>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/ACPLTraining.jpg" alt=""style="height:200px;">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">ACPL training</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden"style="height:200px;">
                            <img class="img-fluid" src="img/
Team ACPL in Skilling.png" alt="">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Team ACPL in Skilling</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden"style="height:200px;">
                            <img class="img-fluid" src="img/traning.jpeg" alt=""style="width:260px;">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Training</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                    <div class="team-item bg-light">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/G5.jpeg" alt="">
                        </div>
                        <!--<div class="position-relative d-flex justify-content-center" style="margin-top: -23px;">-->
                        <!--    <div class="bg-light d-flex justify-content-center pt-2 px-1">-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>-->
                        <!--        <a class="btn btn-sm-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>-->
                        <!--    </div>-->
                        <!--</div>-->
                        <div class="text-center p-4">
                            <h5 class="mb-0">Gift a Bouquet</h5>
                            <small></small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!-fourth gallery end--->
    
    <!--footer section-->
    <?php include 'footer.php'; ?>