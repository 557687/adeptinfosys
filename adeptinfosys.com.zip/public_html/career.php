<?php include 'header.php'; ?>

<!-- Page Banner Start -->
<div class="page-banner-area bgs-cover overlay text-white py-165 rpy-125 rmt-65"
    style="background-image: url(assets/img/background/page-banner.jpg);">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-7 col-lg-8">
                <div class="breadcrumb-inner text-center">
                    <h2 class="page-title">Careers</h2>
                    <ul class="page-list">
                        <li><a href="./">Home</a></li>
                        <li>Career</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Page Banner End -->

<!-- Contact Page Area Start -->
<div class="contact-page-area overflow-hidden py-5 rpt-100">
    <div class="container">
        <div class="row gap-60 align-items-center">
            <div class="col-lg-6">
                <div class="faq-three-left-part mb-20 rel rmb-75">
                    <img src="assets/img/Forward.jpg" alt="Man">
                    <div class="experiences-years">
                        <span class="experiences-years__number">1+</span>
                        <span class="experiences-years__text">Years Experiences</span>
                    </div>
                    <div class="counter-item counter-text-wrap">
                        <div class="counter-item__content">
                            <span class="count-text" data-speed="3000" data-stop="10">0</span>
                            <h5 class="counter-title">Volunteers</h5>
                        </div>
                    </div>
                    <div class="project-complete">
                        <div class="project-complete__icon">
                            <i class="flaticon-charity"></i>
                        </div>
                        <div class="project-complete__content">
                            <h5>We Completed 10+ Projects</h5>
                            <span></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="contact-page-form form-style-two py-110 rpy-85">
                    <div class="section-title mb-10">
                        <span class="section-title__subtitle mb-10">Need help</span>
                        <h3><span>Fill Your Details</span></h3>
                    </div>

                    <form id="careerData" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="name">Your Name <span style="color:red;">*</span></label>
                                    <input type="text" id="name" name="name" class="form-control" placeholder="Your Name">
                                    <span class="error-msg" id="name-error" style="color:red;"></span>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="email">Your Email <span style="color:red;">*</span></label>
                                    <input type="email" id="email" name="email" class="form-control" placeholder="Email Address">
                                    <span class="error-msg" id="email-error" style="color:red;"></span>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="phone">Phone Number <span style="color:red;">*</span></label>
                                    <input type="tel" id="phone" name="phone" class="form-control" placeholder="Phone Number">
                                    <span class="error-msg" id="phone-error" style="color:red;"></span>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="qualification">Qualification <span style="color:red;">*</span></label>
                                    <input type="text" id="qualification" name="qualification" class="form-control">
                                    <span class="error-msg" id="qualification-error" style="color:red;"></span>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="experience">Experience <span style="color:red;">*</span></label>
                                    <input type="text" id="experience" name="experience" class="form-control">
                                    <span class="error-msg" id="experience-error" style="color:red;"></span>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="document">Upload Resume <span style="color:red;">*</span></label>
                                    <input type="file" id="document" name="document" class="form-control">
                                    <span class="error-msg" id="document-error" style="color:red;"></span>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="message">Message <span style="color:red;">*</span></label>
                                    <textarea name="message" id="message" class="form-control" rows="2" placeholder="Write Your Messages"></textarea>
                                    <span class="error-msg" id="message-error" style="color:red;"></span>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group pt-10 mb-0">
                                    <button type="submit" class="btn ml-5" id="career_btn">Send us an application</button>
                                </div>
                            </div>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Contact Page Area End -->

<?php include 'footer.php'; ?>
