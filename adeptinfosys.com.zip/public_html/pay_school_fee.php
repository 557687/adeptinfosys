<?php include 'header.php';?>
<style>
    .card-header {
    background-image: -webkit-linear-gradient(top, #8abf57 0%, #ffffff 100%);
    }
</style>
<div class="container mt-3">
  <div class="card">
    <div class="card-header">
        <span class="title">PAY SCHOOL FEE ONLINE</span>
            <span class="pull-right">
                <a href=""><i class="fa-solid fa-circle-left"></i></a>
            </span>
    </div>
    <div class="card-body">
        <ul>
            <li>
                <p>
                    <a href="parentlogin.php"><span style="font-size:18px;"><strong><span style="color:#b22222;">Click Here For Online School Fee Payment</span></strong></span></a></p>
            </li>
        </ul>
    </div> 
  </div>
</div>
<?php include 'footer.php';?>